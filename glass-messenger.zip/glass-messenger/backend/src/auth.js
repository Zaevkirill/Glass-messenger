import { createHash, randomInt, timingSafeEqual } from 'node:crypto';
import { z } from 'zod';
import { db, normPhone, publicUser } from './db.js';
import { sendOtpEmail } from './mailer.js';

const USERNAME_RE = /^[A-Za-z][A-Za-z0-9_]{4,31}$/;
const hash = (email, code) => createHash('sha256').update(`${email}:${code}`).digest();
const emailSchema = z.string().trim().toLowerCase().email().max(120);

export default async function authRoutes(app) {
  const signUser = (u) => app.jwt.sign({ uid: u.id }, { expiresIn: '30d' });

  // Шаг 1: запрос кода
  app.post('/auth/request-code', { config: { rateLimit: { max: 6, timeWindow: '1 minute' } } }, async (req, reply) => {
    const { email } = z.object({ email: emailSchema }).parse(req.body);
    const row = db.prepare('SELECT last_sent FROM otp WHERE email = ?').get(email);
    if (row && Date.now() - row.last_sent < 30_000) {
      return reply.code(429).send({ error: 'Подождите 30 секунд перед повторной отправкой' });
    }
    const code = randomInt(0, 1_000_000).toString().padStart(6, '0');
    db.prepare(
      `INSERT INTO otp(email, code_hash, expires_at, attempts, last_sent) VALUES(?,?,?,0,?)
       ON CONFLICT(email) DO UPDATE SET code_hash=excluded.code_hash, expires_at=excluded.expires_at,
         attempts=0, last_sent=excluded.last_sent`
    ).run(email, hash(email, code).toString('hex'), Date.now() + 10 * 60_000, Date.now());
    await sendOtpEmail(email, code);
    const expose = process.env.NODE_ENV !== 'production' && process.env.EXPOSE_DEV_CODE !== '0';
    return { ok: true, ...(expose ? { devCode: code } : {}) };
  });

  // Шаг 2: проверка кода
  app.post('/auth/verify-code', { config: { rateLimit: { max: 15, timeWindow: '1 minute' } } }, async (req, reply) => {
    const { email, code } = z.object({ email: emailSchema, code: z.string().regex(/^\d{6}$/) }).parse(req.body);
    const row = db.prepare('SELECT * FROM otp WHERE email = ?').get(email);
    if (!row || row.expires_at < Date.now()) return reply.code(400).send({ error: 'Код истёк. Запросите новый' });
    if (row.attempts >= 5) return reply.code(429).send({ error: 'Слишком много попыток. Запросите новый код' });
    db.prepare('UPDATE otp SET attempts = attempts + 1 WHERE email = ?').run(email);
    const ok = timingSafeEqual(hash(email, code), Buffer.from(row.code_hash, 'hex'));
    if (!ok) return reply.code(400).send({ error: 'Неверный код' });
    db.prepare('DELETE FROM otp WHERE email = ?').run(email);

    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    if (user) return { isNew: false, token: signUser(user), user: publicUser(user) };
    // Новый пользователь — выдаём временный токен регистрации (шаги 3–5)
    return { isNew: true, registrationToken: app.jwt.sign({ email, purpose: 'register' }, { expiresIn: '20m' }) };
  });

  // Шаг 3: проверка доступности @username
  app.get('/auth/username-available', async (req) => {
    const u = String(req.query.u ?? '');
    const valid = USERNAME_RE.test(u);
    const taken = valid && !!db.prepare('SELECT 1 FROM users WHERE username = ?').get(u);
    return { valid, available: valid && !taken };
  });

  // Шаги 3–5: завершение регистрации
  app.post('/auth/register', async (req, reply) => {
    const b = z
      .object({
        registrationToken: z.string(),
        username: z.string().regex(USERNAME_RE),
        firstName: z.string().trim().min(1).max(40),
        lastName: z.string().trim().min(1).max(40),
        phone: z.string().max(25).nullish(),
      })
      .parse(req.body);
    let payload;
    try {
      payload = app.jwt.verify(b.registrationToken);
    } catch {
      return reply.code(401).send({ error: 'Сессия регистрации истекла, начните заново' });
    }
    if (payload.purpose !== 'register') return reply.code(401).send({ error: 'Неверный токен' });

    const phone = normPhone(b.phone);
    if (b.phone && !phone) return reply.code(400).send({ error: 'Некорректный номер телефона' });
    try {
      const info = db
        .prepare('INSERT INTO users(email, username, first_name, last_name, phone, created_at) VALUES(?,?,?,?,?,?)')
        .run(payload.email, b.username, b.firstName, b.lastName, phone, Date.now());
      const user = db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);
      return { token: signUser(user), user: publicUser(user) };
    } catch (e) {
      if (String(e.code).startsWith('SQLITE_CONSTRAINT')) {
        const msg = String(e.message);
        if (msg.includes('username')) return reply.code(409).send({ error: 'Этот @username уже занят' });
        if (msg.includes('phone')) return reply.code(409).send({ error: 'Этот номер уже привязан к другому аккаунту' });
        return reply.code(409).send({ error: 'Аккаунт с такой почтой уже существует' });
      }
      throw e;
    }
  });
}
