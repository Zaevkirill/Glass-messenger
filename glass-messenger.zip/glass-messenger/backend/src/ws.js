import { createHmac } from 'node:crypto';
import { db, convKey, publicUser } from './db.js';

/**
 * Hub — реестр онлайн-сокетов. Сейчас в памяти одного процесса.
 * Для горизонтального масштабирования заменить send() на публикацию в Redis Pub/Sub
 * (канал user:<id>), а каждый инстанс подписывается на каналы своих клиентов.
 */
class Hub {
  sockets = new Map(); // uid -> Set<WebSocket>
  add(uid, ws) { (this.sockets.get(uid) ?? this.sockets.set(uid, new Set()).get(uid)).add(ws); }
  remove(uid, ws) {
    const set = this.sockets.get(uid);
    set?.delete(ws);
    if (set && set.size === 0) this.sockets.delete(uid);
  }
  send(uid, payload) {
    const set = this.sockets.get(uid);
    if (!set || set.size === 0) return false;
    const data = JSON.stringify(payload);
    for (const w of set) if (w.readyState === 1) w.send(data);
    return true;
  }
}
export const hub = new Hub();

const CALL_EVENTS = new Set(['call:offer', 'call:answer', 'call:ice', 'call:end', 'call:reject']);

export default async function wsRoutes(app) {
  // ICE-серверы: STUN + TURN с временными (HMAC) учётными данными для coturn (use-auth-secret)
  app.get('/calls/ice-servers', { preHandler: app.auth }, async (req) => {
    const iceServers = [{ urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] }];
    const { TURN_HOST, TURN_SECRET } = process.env;
    if (TURN_HOST && TURN_SECRET) {
      const username = `${Math.floor(Date.now() / 1000) + 3600}:${req.user.uid}`;
      const credential = createHmac('sha1', TURN_SECRET).update(username).digest('base64');
      iceServers.push({
        urls: [`turn:${TURN_HOST}:3478?transport=udp`, `turn:${TURN_HOST}:3478?transport=tcp`],
        username,
        credential,
      });
    }
    return { iceServers };
  });

  app.get('/ws', { websocket: true }, (socket, req) => {
    let uid;
    try {
      uid = app.jwt.verify(String(req.query.token ?? '')).uid;
      if (!uid) throw new Error('no uid');
    } catch {
      socket.close(4401, 'unauthorized');
      return;
    }
    hub.add(uid, socket);
    const out = (o) => socket.readyState === 1 && socket.send(JSON.stringify(o));

    // Всё, что пришло, пока пользователь был оффлайн, помечаем как доставленное
    const pending = db.prepare("SELECT id, sender_id FROM messages WHERE recipient_id = ? AND status = 'sent'").all(uid);
    if (pending.length) {
      db.prepare("UPDATE messages SET status = 'delivered' WHERE recipient_id = ? AND status = 'sent'").run(uid);
      const bySender = new Map();
      for (const p of pending) (bySender.get(p.sender_id) ?? bySender.set(p.sender_id, []).get(p.sender_id)).push(p.id);
      for (const [sid, ids] of bySender) hub.send(sid, { type: 'message:status', ids, status: 'delivered' });
    }

    socket.on('message', (raw) => {
      let m;
      try { m = JSON.parse(raw.toString()); } catch { return; }

      switch (m.type) {
        case 'ping':
          return out({ type: 'pong' });

        case 'message:send': {
          const to = Number(m.to);
          const text = String(m.text ?? '').trim().slice(0, 4000);
          if (!text || !to || to === uid) return;
          if (!db.prepare('SELECT 1 FROM users WHERE id = ?').get(to)) return;
          const now = Date.now();
          const info = db
            .prepare('INSERT INTO messages(conv, sender_id, recipient_id, text, status, created_at) VALUES(?,?,?,?,?,?)')
            .run(convKey(uid, to), uid, to, text, 'sent', now);
          const id = Number(info.lastInsertRowid);
          const delivered = hub.send(to, {
            type: 'message:new',
            message: { id, from: uid, to, text, status: 'delivered', createdAt: now },
          });
          if (delivered) db.prepare("UPDATE messages SET status = 'delivered' WHERE id = ?").run(id);
          return out({ type: 'message:ack', clientId: m.clientId, id, status: delivered ? 'delivered' : 'sent', createdAt: now });
        }

        case 'message:read': {
          const peer = Number(m.peerId);
          const ids = db
            .prepare("SELECT id FROM messages WHERE recipient_id = ? AND sender_id = ? AND status != 'read'")
            .all(uid, peer)
            .map((r) => r.id);
          if (!ids.length) return;
          db.prepare("UPDATE messages SET status = 'read' WHERE recipient_id = ? AND sender_id = ? AND status != 'read'").run(uid, peer);
          hub.send(peer, { type: 'message:status', ids, status: 'read' });
          return;
        }

        default: {
          // WebRTC-сигналинг: сервер лишь пересылает offer/answer/ICE между двумя пользователями
          if (!CALL_EVENTS.has(m.type)) return;
          const to = Number(m.to);
          if (!to || to === uid) return;
          const { to: _drop, ...rest } = m;
          const payload = { ...rest, from: uid };
          if (m.type === 'call:offer') {
            payload.caller = publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(uid));
          }
          const delivered = hub.send(to, payload);
          if (!delivered && m.type === 'call:offer') out({ type: 'call:unavailable', callId: m.callId });
        }
      }
    });

    socket.on('close', () => hub.remove(uid, socket));
    socket.on('error', () => hub.remove(uid, socket));
  });
}
