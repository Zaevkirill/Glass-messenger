import { z } from 'zod';
import { db, normPhone, publicUser } from './db.js';

export default async function userRoutes(app) {
  app.get('/users/me', { preHandler: app.auth }, async (req) => {
    const u = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.uid);
    return { ...publicUser(u), email: u.email };
  });

  app.patch('/users/me', { preHandler: app.auth }, async (req, reply) => {
    const b = z
      .object({
        firstName: z.string().trim().min(1).max(40).optional(),
        lastName: z.string().trim().min(1).max(40).optional(),
        phone: z.string().max(25).nullish(),
      })
      .parse(req.body);
    const cur = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.uid);
    const phone = b.phone === undefined ? cur.phone : normPhone(b.phone);
    if (b.phone && !phone) return reply.code(400).send({ error: 'Некорректный номер телефона' });
    try {
      db.prepare('UPDATE users SET first_name=?, last_name=?, phone=? WHERE id=?').run(
        b.firstName ?? cur.first_name, b.lastName ?? cur.last_name, phone, cur.id);
    } catch {
      return reply.code(409).send({ error: 'Этот номер уже привязан к другому аккаунту' });
    }
    return publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(cur.id));
  });

  // Поиск: "@username" / "username" — по префиксу; номер телефона — только точное совпадение (приватность)
  app.get('/users/search', { preHandler: app.auth, config: { rateLimit: { max: 40, timeWindow: '1 minute' } } }, async (req) => {
    const q = String(req.query.q ?? '').trim();
    if (q.length < 2) return [];
    const me = req.user.uid;
    let rows;
    if (/^\+?[\d\s()\-]{5,}$/.test(q)) {
      const phone = normPhone(q);
      rows = phone ? db.prepare('SELECT * FROM users WHERE phone = ? AND id != ?').all(phone, me) : [];
    } else {
      const name = q.replace(/^@/, '').replace(/[\\%_]/g, '\\$&');
      rows = db
        .prepare("SELECT * FROM users WHERE username LIKE ? ESCAPE '\\' AND id != ? ORDER BY username LIMIT 20")
        .all(name + '%', me);
    }
    return rows.map(publicUser);
  });
}
