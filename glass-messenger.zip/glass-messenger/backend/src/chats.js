import { db, convKey, publicUser } from './db.js';

const toMsg = (m) => ({ id: m.id, from: m.sender_id, to: m.recipient_id, text: m.text, status: m.status, createdAt: m.created_at });

export default async function chatRoutes(app) {
  // Список диалогов: последнее сообщение + непрочитанные
  app.get('/chats', { preHandler: app.auth }, async (req) => {
    const me = req.user.uid;
    const lasts = db
      .prepare(
        `SELECT * FROM messages WHERE id IN (
           SELECT MAX(id) FROM messages WHERE sender_id = @me OR recipient_id = @me GROUP BY conv
         ) ORDER BY id DESC`
      )
      .all({ me });
    const getUser = db.prepare('SELECT * FROM users WHERE id = ?');
    const unread = db.prepare("SELECT COUNT(*) AS n FROM messages WHERE recipient_id = ? AND sender_id = ? AND status != 'read'");
    return lasts.map((m) => {
      const peerId = m.sender_id === me ? m.recipient_id : m.sender_id;
      return { peer: publicUser(getUser.get(peerId)), last: toMsg(m), unread: unread.get(me, peerId).n };
    });
  });

  // История сообщений (старые — через ?before=<id>)
  app.get('/chats/:peerId/messages', { preHandler: app.auth }, async (req) => {
    const me = req.user.uid;
    const peer = Number(req.params.peerId);
    const before = Number(req.query.before) || Number.MAX_SAFE_INTEGER;
    const limit = Math.min(Number(req.query.limit) || 50, 100);
    const rows = db
      .prepare('SELECT * FROM messages WHERE conv = ? AND id < ? ORDER BY id DESC LIMIT ?')
      .all(convKey(me, peer), before, limit);
    return rows.reverse().map(toMsg);
  });
}
