// МОК-сервис отправки писем. Позже заменить на SMTP (nodemailer) / Firebase / SendGrid / AWS SES.
// Интерфейс остаётся тем же: sendOtpEmail(email, code).
export async function sendOtpEmail(email, code) {
  console.log(`\n[MOCK MAIL] → ${email} | код подтверждения: ${code}\n`);
}
