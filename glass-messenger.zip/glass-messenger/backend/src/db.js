import Database from 'better-sqlite3';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';

const path = process.env.DB_PATH || 'data/app.db';
mkdirSync(dirname(path), { recursive: true });

export const db = new Database(path);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// Схема намеренно простая и совместима с PostgreSQL (при переезде меняется только драйвер).
db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  email       TEXT NOT NULL UNIQUE,
  username    TEXT NOT NULL UNIQUE COLLATE NOCASE,
  first_name  TEXT NOT NULL,
  last_name   TEXT NOT NULL,
  phone       TEXT UNIQUE,
  created_at  INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS otp (
  email      TEXT PRIMARY KEY,
  code_hash  TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  attempts   INTEGER NOT NULL DEFAULT 0,
  last_sent  INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS messages (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  conv         TEXT NOT NULL,              -- "minId_maxId" — ключ диалога 1-на-1
  sender_id    INTEGER NOT NULL REFERENCES users(id),
  recipient_id INTEGER NOT NULL REFERENCES users(id),
  text         TEXT NOT NULL,
  status       TEXT NOT NULL DEFAULT 'sent', -- sent | delivered | read
  created_at   INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_messages_conv ON messages(conv, id);
CREATE INDEX IF NOT EXISTS idx_messages_recipient ON messages(recipient_id, status);
`);

export const convKey = (a, b) => (a < b ? `${a}_${b}` : `${b}_${a}`);

export function normPhone(input) {
  if (!input) return null;
  let d = String(input).replace(/\D/g, '');
  if (d.length === 11 && d.startsWith('8')) d = '7' + d.slice(1); // RU: 8XXXXXXXXXX -> +7XXXXXXXXXX
  return d.length >= 7 && d.length <= 15 ? '+' + d : null;
}

export const publicUser = (u) => ({
  id: u.id,
  username: u.username,
  firstName: u.first_name,
  lastName: u.last_name,
  phone: u.phone,
});
