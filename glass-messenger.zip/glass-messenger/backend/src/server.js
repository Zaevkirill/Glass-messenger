import Fastify from 'fastify';
import cors from '@fastify/cors';
import jwt from '@fastify/jwt';
import rateLimit from '@fastify/rate-limit';
import websocket from '@fastify/websocket';
import { ZodError } from 'zod';
import authRoutes from './auth.js';
import userRoutes from './users.js';
import chatRoutes from './chats.js';
import wsRoutes from './ws.js';

const isProd = process.env.NODE_ENV === 'production';
if (isProd && !process.env.JWT_SECRET) throw new Error('JWT_SECRET is required in production');

const app = Fastify({ logger: { level: isProd ? 'info' : 'warn' } });

await app.register(cors, { origin: true });
await app.register(rateLimit, { max: 200, timeWindow: '1 minute' });
await app.register(jwt, { secret: process.env.JWT_SECRET || 'dev-secret-change-me' });
await app.register(websocket, { options: { maxPayload: 64 * 1024 } });

app.decorate('auth', async (req, reply) => {
  try {
    await req.jwtVerify();
    if (!req.user.uid) throw new Error('not a session token');
  } catch {
    reply.code(401).send({ error: 'unauthorized' });
  }
});

app.setErrorHandler((err, _req, reply) => {
  if (err instanceof ZodError) return reply.code(400).send({ error: 'Некорректные данные' });
  const status = err.statusCode ?? 500;
  if (status >= 500) app.log.error(err);
  reply.code(status).send({ error: status < 500 ? err.message : 'Внутренняя ошибка сервера' });
});

app.get('/health', async () => ({ ok: true }));
await app.register(authRoutes);
await app.register(userRoutes);
await app.register(chatRoutes);
await app.register(wsRoutes);

const port = Number(process.env.PORT || 3000);
await app.listen({ port, host: '0.0.0.0' });
console.log(`Glass backend listening on :${port}`);
