# Glass Messenger — этап 1

Мессенджер в стиле «Жидкое стекло» (Dark Glass / Light Glass).
**Flutter** (клиент, Android APK) + **Node.js / Fastify** (REST + WebSocket + WebRTC-сигналинг) + **SQLite** (на старте; схема совместима с PostgreSQL).

## Структура

```
glass-messenger/
├── docker-compose.yml        # api (+ coturn по профилю "turn")
├── backend/
│   ├── Dockerfile, package.json, .env.example
│   └── src/
│       ├── server.js         # Fastify, JWT, CORS, rate-limit, единый обработчик ошибок
│       ├── db.js             # схема: users, otp, messages (+ индексы)
│       ├── mailer.js         # МОК отправки email (код пишется в консоль) → заменить на SMTP
│       ├── auth.js           # request-code → verify-code → username-available → register
│       ├── users.js          # /users/me, поиск по @username / телефону
│       ├── chats.js          # список диалогов, история сообщений
│       └── ws.js             # WebSocket: сообщения, статусы, WebRTC-сигналинг, TURN-учётки
└── app/
    ├── pubspec.yaml, patch_android.py
    └── lib/
        ├── main.dart                     # тема, провайдеры, Gate (auth ↔ home)
        ├── core/                         # config, api, socket (авто-реконнект), session, theme, glass-виджеты
        └── features/
            ├── auth/auth_flow.dart       # 5 шагов регистрации
            ├── chats/                    # главный экран, новый чат (поиск), нижняя навигация
            ├── chat/chat_screen.dart     # сообщения, статусы ✓ ✓✓, время
            ├── settings/                 # профиль, смена темы, выход
            └── calls/                    # WebRTC: CallService + экран звонка
```

## 1. Запуск бэкенда локально

Нужен Node.js 20+.

```bash
cd backend
npm install
npm run dev          # сервер на http://localhost:3000
```

Проверка: откройте http://localhost:3000/health → `{"ok":true}`.
Код подтверждения печатается в консоль сервера (`[MOCK MAIL] ...`), а в dev-режиме ещё и показывается в приложении.

## 2. Подготовка Flutter-приложения

Нужны: Flutter SDK 3.22+ (`flutter doctor` без ошибок), Android Studio (SDK + эмулятор) или телефон с включённой отладкой по USB.

```bash
cd app
flutter create . --project-name glass_messenger --org com.glass --platforms=android
rm -f test/widget_test.dart          # шаблонный тест не нужен
python3 patch_android.py             # разрешения: интернет, камера, микрофон
flutter pub get
```

Если `flutter create` перезаписал `pubspec.yaml` или `lib/main.dart` — верните файлы из архива.

Если при сборке ошибка про `minSdk`, в `android/app/build.gradle(.kts)` поставьте `minSdk = 24`.

## 3. Запуск и тест

Адрес сервера задаётся при запуске через `--dart-define`:

| Где запускаете                | Команда                                                          |
|-------------------------------|------------------------------------------------------------------|
| Эмулятор Android              | `flutter run`  (по умолчанию `10.0.2.2:3000`)                    |
| Реальный телефон (тот же Wi-Fi) | `flutter run --dart-define=API_HOST=192.168.1.50:3000`  (IP вашего ПК: `ipconfig` / `ifconfig`) |

Если телефон не достаёт до ПК — разрешите порт 3000 во входящих правилах брандмауэра.

**Сценарий проверки (нужны 2 устройства/эмулятора, например эмулятор + телефон):**
1. На первом: email `a@test.com` → код (виден в карточке DEV и в консоли сервера) → `@alice_01` → имя → телефон `+7 999 111-22-33` (или «Пропустить»).
2. На втором: `b@test.com` → `@bobby_02` → имя → без телефона.
3. На втором: ✎ (новый чат) → `@alice` или `+7 999 111-22-33` → откройте чат → отправьте сообщение.
4. На первом: сообщение приходит мгновенно; статусы: ✓ отправлено → ✓✓ доставлено → ✓✓ (бирюзовые) прочитано.
5. Звонки: в чате 📞 / 📹 → на другом устройстве экран входящего → «принять».
6. Настройки → переключите Dark Glass / Light Glass; «Выйти» → повторный вход по тому же email восстанавливает аккаунт.
7. Отключите Wi-Fi на устройстве, отправьте сообщение → «Не отправлено», после возврата сети нажмите на него для повтора (сокет переподключается сам).

## 4. Сборка APK

```bash
cd app
flutter build apk --release --dart-define=API_HOST=192.168.1.50:3000
# или для продакшена:
# flutter build apk --release --dart-define=API_HOST=api.example.com --dart-define=API_SECURE=true
```

Готовый файл: `app/build/app/outputs/flutter-apk/app-release.apk` — перенесите на телефон и установите.
Для меньшего размера: `flutter build apk --release --split-per-abi`.
Для публикации в Google Play: `flutter build appbundle` + собственный keystore (https://docs.flutter.dev/deployment/android).

## 5. Перенос на сервер (Docker / VPS / AWS)

```bash
# на VPS (Ubuntu + Docker):
cp .env.example .env && nano .env            # JWT_SECRET, TURN_*
docker compose up -d --build                 # API
docker compose --profile turn up -d coturn   # TURN для звонков
```

* Поставьте перед API reverse-proxy с HTTPS (Caddy / nginx + Let's Encrypt) и проксируйте `/ws` с заголовками Upgrade — в приложении тогда `API_SECURE=true`.
* **Почта:** замените тело `sendOtpEmail` в `backend/src/mailer.js` на nodemailer (SMTP) / SES / SendGrid / Firebase — сигнатура не меняется. В production `EXPOSE_DEV_CODE=0` (код в ответе API не отдаётся).
* **База:** SQLite подходит для старта. Для роста — PostgreSQL (SQL в `db.js` простой, меняется драйвер).
* **Горизонтальное масштабирование:** класс `Hub` в `ws.js` — единственное место, знающее об онлайн-сокетах. Замените его `send()` на Redis Pub/Sub, и API можно запускать в нескольких экземплярах за балансировщиком (sticky-сессии не нужны).

## 6. Звонки: как это работает и как добиться «без задержек везде»

* Медиа идёт **напрямую P2P** (WebRTC), сервер только пересылает offer/answer/ICE по WebSocket — поэтому нагрузка на сервер минимальна, а задержка минимальна по определению.
* Если прямой путь невозможен (строгий NAT, мобильные сети), трафик идёт через **TURN (coturn)**. Без TURN часть звонков между разными сетями не соединится — это главное условие работы «во всех странах».
* Бэкенд выдаёт клиенту временные TURN-учётки (`GET /calls/ice-servers`, HMAC, срок 1 час) — статических паролей в приложении нет.
* Для глобальной работы разверните coturn в нескольких регионах (EU/US/Asia) и отдавайте клиенту ближайший (например, по GeoDNS).
* Качество подстраивается автоматически (встроенный congestion control WebRTC); видео ограничено 640×480@24 — комфортно на слабых каналах.
* Если не хотите администрировать TURN — альтернатива: LiveKit Cloud / Agora / Jitsi; тогда `CallService` заменяется на их SDK, а сигналинг не нужен.

## Что дальше (этап 2)

Push-уведомления (FCM) и звонки при закрытом приложении (CallKit/ConnectionService), аватары (загрузка в S3), редактирование профиля, групповые чаты, вложения (фото/файлы), «печатает…», онлайн-статус, E2E-шифрование.
