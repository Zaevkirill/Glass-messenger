import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../features/calls/call_service.dart';
import 'api.dart';
import 'models.dart';
import 'socket.dart';

/// Список диалогов. Обновляется по событиям сокета (с небольшим debounce).
class ChatsState extends ChangeNotifier {
  ChatsState(this._api, this._socket) {
    _socket.events.listen((m) {
      switch (m['type']) {
        case 'socket:open':
        case 'message:new':
        case 'message:ack':
        case 'message:status':
          _deb?.cancel();
          _deb = Timer(const Duration(milliseconds: 250), refresh);
      }
    });
  }
  final Api _api;
  final ChatSocket _socket;
  List<ChatPreview> chats = [];
  bool loading = false;
  String? error;
  Timer? _deb;

  Future<void> refresh() async {
    if (_api.token == null) return;
    loading = chats.isEmpty;
    notifyListeners();
    try {
      chats = await _api.chats();
      error = null;
    } on ApiError catch (e) {
      error = e.message;
    }
    loading = false;
    notifyListeners();
  }

  void clear() {
    chats = [];
    error = null;
    notifyListeners();
  }
}

/// Сессия: токен, текущий пользователь, сокет, звонки.
class AppState extends ChangeNotifier {
  AppState() {
    chats = ChatsState(api, socket);
    calls = CallService(api, socket);
  }

  final Api api = Api();
  final ChatSocket socket = ChatSocket();
  late final ChatsState chats;
  late final CallService calls;

  bool loaded = false;
  AppUser? user;
  SharedPreferences? _p;

  Future<void> load() async {
    _p = await SharedPreferences.getInstance();
    final token = _p!.getString('token');
    if (token != null) {
      api.token = token;
      final cached = _p!.getString('user');
      if (cached != null) user = AppUser.fromJson(Map<String, dynamic>.from(jsonDecode(cached) as Map));
      try {
        user = await api.me();
        await _p!.setString('user', jsonEncode(user!.toJson()));
      } on ApiError catch (e) {
        if (e.status == 401) {
          await _clear();
        } // иначе (нет сети) работаем с закэшированным профилем
      }
      if (user != null) _startSession(token);
    }
    loaded = true;
    notifyListeners();
  }

  void _startSession(String token) {
    socket.connect(token);
    chats.refresh();
  }

  Future<void> setSession(String token, AppUser u) async {
    _p ??= await SharedPreferences.getInstance();
    await _p!.setString('token', token);
    await _p!.setString('user', jsonEncode(u.toJson()));
    api.token = token;
    user = u;
    _startSession(token);
    notifyListeners();
  }

  Future<void> _clear() async {
    await _p?.remove('token');
    await _p?.remove('user');
    api.token = null;
    user = null;
  }

  Future<void> logout() async {
    calls.end();
    socket.disconnect();
    chats.clear();
    await _clear();
    notifyListeners();
  }
}
