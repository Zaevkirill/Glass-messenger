import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

@immutable
class GlassColors extends ThemeExtension<GlassColors> {
  const GlassColors({
    required this.bg, required this.fill, required this.fillStrong, required this.border,
    required this.neon, required this.neon2, required this.textDim, required this.blobA, required this.blobB,
  });
  final List<Color> bg;
  final Color fill, fillStrong, border, neon, neon2, textDim, blobA, blobB;

  /// Dark Glass — глубокий чёрный
  static const dark = GlassColors(
    bg: [Color(0xFF040509), Color(0xFF0A0C16), Color(0xFF05060B)],
    fill: Color(0x1AFFFFFF), fillStrong: Color(0x2EFFFFFF), border: Color(0x33FFFFFF),
    neon: Color(0xFF8B5CFF), neon2: Color(0xFF00E5FF), textDim: Color(0x99FFFFFF),
    blobA: Color(0xFF6D3BFF), blobB: Color(0xFF00B8FF),
  );

  /// Light Glass — чистый белый
  static const light = GlassColors(
    bg: [Color(0xFFFFFFFF), Color(0xFFEFF3FF), Color(0xFFFFFFFF)],
    fill: Color(0xB3FFFFFF), fillStrong: Color(0xE6FFFFFF), border: Color(0x336B7BB5),
    neon: Color(0xFF5B6CFF), neon2: Color(0xFF00B8D9), textDim: Color(0x99101428),
    blobA: Color(0xFF9DB0FF), blobB: Color(0xFF8BE9FF),
  );

  @override
  GlassColors copyWith() => this;

  @override
  GlassColors lerp(ThemeExtension<GlassColors>? other, double t) {
    if (other is! GlassColors) return this;
    Color l(Color a, Color b) => Color.lerp(a, b, t)!;
    return GlassColors(
      bg: [for (var i = 0; i < bg.length; i++) l(bg[i], other.bg[i])],
      fill: l(fill, other.fill), fillStrong: l(fillStrong, other.fillStrong), border: l(border, other.border),
      neon: l(neon, other.neon), neon2: l(neon2, other.neon2), textDim: l(textDim, other.textDim),
      blobA: l(blobA, other.blobA), blobB: l(blobB, other.blobB),
    );
  }
}

extension GlassCtx on BuildContext {
  GlassColors get g => Theme.of(this).extension<GlassColors>()!;
  bool get isDark => Theme.of(this).brightness == Brightness.dark;
}

ThemeData buildTheme(Brightness b) {
  final c = b == Brightness.dark ? GlassColors.dark : GlassColors.light;
  final text = b == Brightness.dark ? Colors.white : const Color(0xFF0E1222);
  final base = ThemeData(
    brightness: b,
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(seedColor: c.neon, brightness: b),
  );
  return base.copyWith(
    scaffoldBackgroundColor: Colors.transparent,
    textTheme: base.textTheme.apply(bodyColor: text, displayColor: text),
    iconTheme: IconThemeData(color: text),
    extensions: [c],
  );
}

class ThemeController extends ChangeNotifier {
  ThemeMode mode = ThemeMode.dark;

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    mode = p.getString('theme') == 'light' ? ThemeMode.light : ThemeMode.dark;
    notifyListeners();
  }

  Future<void> set(ThemeMode m) async {
    mode = m;
    notifyListeners();
    final p = await SharedPreferences.getInstance();
    await p.setString('theme', m == ThemeMode.light ? 'light' : 'dark');
  }
}
