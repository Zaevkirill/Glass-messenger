import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'theme.dart';

/// Фон: градиент + мягкие цветные «пятна», сквозь которые и преломляется стекло.
class GlassBackground extends StatelessWidget {
  const GlassBackground({super.key, required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final g = context.g;
    return Stack(fit: StackFit.expand, children: [
      DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: g.bg),
        ),
      ),
      Positioned(top: -120, left: -90, child: _Blob(g.blobA, 340)),
      Positioned(top: 320, right: -170, child: _Blob(g.blobA, 280)),
      Positioned(bottom: -140, right: -100, child: _Blob(g.blobB, 380)),
      Positioned(bottom: 120, left: -160, child: _Blob(g.blobB, 260)),
      child,
    ]);
  }
}

class _Blob extends StatelessWidget {
  const _Blob(this.color, this.size);
  final Color color;
  final double size;
  @override
  Widget build(BuildContext context) => IgnorePointer(
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(colors: [color.withAlpha(context.isDark ? 120 : 150), color.withAlpha(0)]),
          ),
        ),
      );
}

class GlassScaffold extends StatelessWidget {
  const GlassScaffold({super.key, required this.body, this.bottom, this.appBar, this.resize = true});
  final Widget body;
  final Widget? bottom;
  final PreferredSizeWidget? appBar;
  final bool resize;

  @override
  Widget build(BuildContext context) => GlassBackground(
        child: Scaffold(
          backgroundColor: Colors.transparent,
          resizeToAvoidBottomInset: resize,
          extendBody: true,
          appBar: appBar,
          body: body,
          bottomNavigationBar: bottom,
        ),
      );
}

AppBar glassAppBar(BuildContext context, {Widget? title, List<Widget>? actions}) => AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
      title: title,
      actions: actions,
    );

class GlassCard extends StatelessWidget {
  const GlassCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.radius = 24,
    this.onTap,
    this.strong = false,
    this.glow = false,
    this.blur = 20,
  });
  final Widget child;
  final EdgeInsetsGeometry padding;
  final double radius, blur;
  final VoidCallback? onTap;
  final bool strong, glow;

  @override
  Widget build(BuildContext context) {
    final g = context.g;
    final r = BorderRadius.circular(radius);
    final card = ClipRRect(
      borderRadius: r,
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            borderRadius: r,
            color: strong ? g.fillStrong : g.fill,
            border: Border.all(color: glow ? g.neon.withAlpha(170) : g.border, width: 1),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Colors.white.withAlpha(context.isDark ? 30 : 110), Colors.white.withAlpha(0)],
            ),
          ),
          child: child,
        ),
      ),
    );
    return onTap == null ? card : GestureDetector(behavior: HitTestBehavior.opaque, onTap: onTap, child: card);
  }
}

class GlassButton extends StatelessWidget {
  const GlassButton({super.key, required this.label, required this.onPressed, this.loading = false, this.danger = false, this.icon});
  final String label;
  final VoidCallback? onPressed;
  final bool loading, danger;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    final g = context.g;
    final enabled = onPressed != null && !loading;
    final colors = danger ? [const Color(0xFFFF4D6D), const Color(0xFFFF8A5B)] : [g.neon, g.neon2];
    return AnimatedOpacity(
      duration: const Duration(milliseconds: 200),
      opacity: enabled ? 1 : 0.45,
      child: GestureDetector(
        onTap: enabled ? onPressed : null,
        child: Container(
          height: 54,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            gradient: LinearGradient(colors: colors),
            boxShadow: [BoxShadow(color: colors.first.withAlpha(90), blurRadius: 22, offset: const Offset(0, 8))],
          ),
          child: loading
              ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.4, color: Colors.white))
              : Row(mainAxisSize: MainAxisSize.min, children: [
                  if (icon != null) ...[Icon(icon, color: Colors.white, size: 20), const SizedBox(width: 8)],
                  Text(label, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600)),
                ]),
        ),
      ),
    );
  }
}

class GlassIconButton extends StatelessWidget {
  const GlassIconButton({super.key, required this.icon, required this.onTap, this.size = 44});
  final IconData icon;
  final VoidCallback onTap;
  final double size;
  @override
  Widget build(BuildContext context) => GlassCard(
        onTap: onTap,
        radius: size / 2,
        padding: EdgeInsets.zero,
        blur: 12,
        child: SizedBox(width: size, height: size, child: Icon(icon, size: size * 0.5)),
      );
}

class GlassTextField extends StatelessWidget {
  const GlassTextField({
    super.key,
    required this.controller,
    required this.hint,
    this.icon,
    this.keyboardType,
    this.onChanged,
    this.onSubmitted,
    this.inputFormatters,
    this.maxLength,
    this.maxLines = 1,
    this.autofocus = false,
    this.textInputAction,
    this.prefixText,
    this.textStyle,
    this.textAlign = TextAlign.start,
  });
  final TextEditingController controller;
  final String hint;
  final IconData? icon;
  final TextInputType? keyboardType;
  final ValueChanged<String>? onChanged, onSubmitted;
  final List<TextInputFormatter>? inputFormatters;
  final int? maxLength;
  final int maxLines;
  final bool autofocus;
  final TextInputAction? textInputAction;
  final String? prefixText;
  final TextStyle? textStyle;
  final TextAlign textAlign;

  @override
  Widget build(BuildContext context) {
    final g = context.g;
    return GlassCard(
      radius: 18,
      blur: 14,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
      child: TextField(
        controller: controller,
        autofocus: autofocus,
        keyboardType: keyboardType,
        onChanged: onChanged,
        onSubmitted: onSubmitted,
        inputFormatters: inputFormatters,
        maxLength: maxLength,
        minLines: 1,
        maxLines: maxLines,
        textInputAction: textInputAction,
        textAlign: textAlign,
        style: textStyle,
        cursorColor: g.neon2,
        decoration: InputDecoration(
          border: InputBorder.none,
          enabledBorder: InputBorder.none,
          focusedBorder: InputBorder.none,
          filled: false,
          counterText: '',
          hintText: hint,
          hintStyle: TextStyle(color: g.textDim),
          prefixText: prefixText,
          prefixStyle: textStyle ?? TextStyle(color: g.textDim),
          prefixIcon: icon == null ? null : Icon(icon, color: g.textDim),
          prefixIconConstraints: icon == null ? null : const BoxConstraints(minWidth: 36),
        ),
      ),
    );
  }
}

class GlassAvatar extends StatelessWidget {
  const GlassAvatar({super.key, required this.initials, this.size = 48});
  final String initials;
  final double size;
  @override
  Widget build(BuildContext context) {
    final g = context.g;
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [g.neon, g.neon2]),
        boxShadow: [BoxShadow(color: g.neon.withAlpha(80), blurRadius: 14)],
      ),
      child: Text(initials, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: size * 0.36)),
    );
  }
}

/// Плавное появление (fade + сдвиг вверх)
class FadeSlideIn extends StatelessWidget {
  const FadeSlideIn({super.key, required this.child, this.index = 0});
  final Widget child;
  final int index;
  @override
  Widget build(BuildContext context) => TweenAnimationBuilder<double>(
        tween: Tween(begin: 0, end: 1),
        duration: Duration(milliseconds: 320 + (index > 8 ? 8 : index) * 45),
        curve: Curves.easeOutCubic,
        builder: (_, v, c) => Opacity(opacity: v, child: Transform.translate(offset: Offset(0, (1 - v) * 18), child: c)),
        child: child,
      );
}

class StatusTicks extends StatelessWidget {
  const StatusTicks(this.status, {super.key, this.color});
  final String status;
  final Color? color;
  @override
  Widget build(BuildContext context) {
    final g = context.g;
    switch (status) {
      case 'sending':
        return Icon(Icons.access_time_rounded, size: 14, color: color ?? g.textDim);
      case 'failed':
        return const Icon(Icons.error_outline_rounded, size: 15, color: Color(0xFFFF5470));
      case 'sent':
        return Icon(Icons.done_rounded, size: 16, color: color ?? g.textDim);
      case 'delivered':
        return Icon(Icons.done_all_rounded, size: 16, color: color ?? g.textDim);
      default: // read
        return Icon(Icons.done_all_rounded, size: 16, color: g.neon2);
    }
  }
}
