class Config {
  /// Адрес сервера. Задаётся при сборке: --dart-define=API_HOST=192.168.1.50:3000
  /// Эмулятор Android -> ваш ПК: 10.0.2.2:3000. Реальный телефон: IP ПК в Wi-Fi сети.
  /// Прод: --dart-define=API_HOST=api.example.com --dart-define=API_SECURE=true
  static const host = String.fromEnvironment('API_HOST', defaultValue: '10.0.2.2:3000');
  static const secure = bool.fromEnvironment('API_SECURE', defaultValue: false);
  static String get httpBase => '${secure ? 'https' : 'http'}://$host';
  static String get wsBase => '${secure ? 'wss' : 'ws'}://$host';
}
