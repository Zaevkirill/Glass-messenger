class AppUser {
  final int id;
  final String username, firstName, lastName;
  final String? phone, email;
  AppUser({required this.id, required this.username, required this.firstName, required this.lastName, this.phone, this.email});

  factory AppUser.fromJson(Map<String, dynamic> j) => AppUser(
        id: j['id'] as int,
        username: j['username'] as String,
        firstName: j['firstName'] as String,
        lastName: j['lastName'] as String,
        phone: j['phone'] as String?,
        email: j['email'] as String?,
      );

  Map<String, dynamic> toJson() => {
        'id': id, 'username': username, 'firstName': firstName, 'lastName': lastName, 'phone': phone, 'email': email,
      };

  String get fullName => '$firstName $lastName'.trim();
  String get initials {
    final a = firstName.isNotEmpty ? firstName[0] : '';
    final b = lastName.isNotEmpty ? lastName[0] : '';
    return (a + b).toUpperCase();
  }
}

const statusOrder = {'failed': -1, 'sending': 0, 'sent': 1, 'delivered': 2, 'read': 3};

class Msg {
  int? id;
  final String clientId;
  final int from, to;
  final String text;
  String status;
  DateTime createdAt;
  Msg({this.id, required this.clientId, required this.from, required this.to, required this.text, required this.status, required this.createdAt});

  factory Msg.fromJson(Map<String, dynamic> j) => Msg(
        id: j['id'] as int,
        clientId: 'srv-${j['id']}',
        from: j['from'] as int,
        to: j['to'] as int,
        text: j['text'] as String,
        status: j['status'] as String,
        createdAt: DateTime.fromMillisecondsSinceEpoch(j['createdAt'] as int),
      );

  /// Статус можно только «повышать» (sent -> delivered -> read)
  void upgrade(String s) {
    if ((statusOrder[s] ?? 0) > (statusOrder[status] ?? 0)) status = s;
  }
}

class ChatPreview {
  final AppUser peer;
  final Msg last;
  final int unread;
  ChatPreview(this.peer, this.last, this.unread);
  factory ChatPreview.fromJson(Map<String, dynamic> j) => ChatPreview(
        AppUser.fromJson(Map<String, dynamic>.from(j['peer'] as Map)),
        Msg.fromJson(Map<String, dynamic>.from(j['last'] as Map)),
        j['unread'] as int,
      );
}

String fmtTime(DateTime t) {
  final l = t.toLocal();
  return '${l.hour.toString().padLeft(2, '0')}:${l.minute.toString().padLeft(2, '0')}';
}

String fmtChatTime(DateTime t) {
  final now = DateTime.now();
  final l = t.toLocal();
  final days = DateTime(now.year, now.month, now.day).difference(DateTime(l.year, l.month, l.day)).inDays;
  if (days == 0) return fmtTime(l);
  if (days == 1) return 'Вчера';
  return '${l.day.toString().padLeft(2, '0')}.${l.month.toString().padLeft(2, '0')}';
}
