import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'config.dart';
import 'models.dart';

class ApiError implements Exception {
  final String message;
  final int? status;
  ApiError(this.message, [this.status]);
  @override
  String toString() => message;
}

class Api {
  String? token;

  Map<String, String> get _headers => {
        'Content-Type': 'application/json',
        if (token != null) 'Authorization': 'Bearer $token',
      };

  Future<dynamic> _send(String method, String path, {Map<String, dynamic>? body, Map<String, String>? query}) async {
    final uri = Uri.parse('${Config.httpBase}$path').replace(queryParameters: query);
    try {
      final req = http.Request(method, uri)..headers.addAll(_headers);
      if (body != null) req.body = jsonEncode(body);
      final res = await http.Response.fromStream(await req.send().timeout(const Duration(seconds: 15)));
      final data = res.body.isEmpty ? null : jsonDecode(utf8.decode(res.bodyBytes));
      if (res.statusCode >= 400) {
        final msg = data is Map && data['error'] != null ? data['error'].toString() : 'Ошибка ${res.statusCode}';
        throw ApiError(msg, res.statusCode);
      }
      return data;
    } on SocketException {
      throw ApiError('Нет соединения с сервером');
    } on TimeoutException {
      throw ApiError('Сервер не отвечает');
    } on http.ClientException {
      throw ApiError('Нет соединения с сервером');
    }
  }

  Future<dynamic> get(String path, {Map<String, String>? query}) => _send('GET', path, query: query);
  Future<dynamic> post(String path, Map<String, dynamic> body) => _send('POST', path, body: body);

  // --- Авторизация ---
  Future<Map<String, dynamic>> requestCode(String email) async =>
      Map<String, dynamic>.from(await post('/auth/request-code', {'email': email}) as Map);

  Future<Map<String, dynamic>> verifyCode(String email, String code) async =>
      Map<String, dynamic>.from(await post('/auth/verify-code', {'email': email, 'code': code}) as Map);

  Future<bool> usernameAvailable(String u) async {
    final d = await get('/auth/username-available', query: {'u': u});
    return d['available'] == true;
  }

  Future<Map<String, dynamic>> register({
    required String registrationToken,
    required String username,
    required String firstName,
    required String lastName,
    String? phone,
  }) async =>
      Map<String, dynamic>.from(await post('/auth/register', {
        'registrationToken': registrationToken,
        'username': username,
        'firstName': firstName,
        'lastName': lastName,
        'phone': phone,
      }) as Map);

  // --- Данные ---
  Future<AppUser> me() async => AppUser.fromJson(Map<String, dynamic>.from(await get('/users/me') as Map));

  Future<List<AppUser>> search(String q) async {
    final d = await get('/users/search', query: {'q': q}) as List;
    return d.map((e) => AppUser.fromJson(Map<String, dynamic>.from(e as Map))).toList();
  }

  Future<List<ChatPreview>> chats() async {
    final d = await get('/chats') as List;
    return d.map((e) => ChatPreview.fromJson(Map<String, dynamic>.from(e as Map))).toList();
  }

  Future<List<Msg>> messages(int peerId) async {
    final d = await get('/chats/$peerId/messages') as List;
    return d.map((e) => Msg.fromJson(Map<String, dynamic>.from(e as Map))).toList();
  }
}
