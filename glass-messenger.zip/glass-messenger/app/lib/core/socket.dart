import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'config.dart';

/// WebSocket-клиент с авто-переподключением (экспоненциальная задержка) и ping.
/// События сервера приходят в [events]; при (пере)подключении эмитится {'type': 'socket:open'}.
class ChatSocket {
  final _ctrl = StreamController<Map<String, dynamic>>.broadcast();
  Stream<Map<String, dynamic>> get events => _ctrl.stream;
  final ValueNotifier<bool> connected = ValueNotifier(false);

  WebSocketChannel? _ch;
  String? _token;
  bool _closed = true;
  int _retry = 0;
  Timer? _ping, _reconnect;

  void connect(String token) {
    _token = token;
    _closed = false;
    _open();
  }

  void _open() {
    _reconnect?.cancel();
    _ch?.sink.close();
    final ch = WebSocketChannel.connect(Uri.parse('${Config.wsBase}/ws?token=$_token'));
    _ch = ch;
    ch.ready.then((_) {
      if (_ch != ch) return;
      connected.value = true;
      _retry = 0;
      _ping?.cancel();
      _ping = Timer.periodic(const Duration(seconds: 25), (_) => send({'type': 'ping'}));
      _ctrl.add({'type': 'socket:open'});
    }).catchError((_) {});
    ch.stream.listen(
      (raw) {
        try {
          final m = jsonDecode(raw as String);
          if (m is Map) _ctrl.add(Map<String, dynamic>.from(m));
        } catch (_) {}
      },
      onDone: () => _onClosed(ch),
      onError: (_) => _onClosed(ch),
    );
  }

  void _onClosed(WebSocketChannel ch) {
    if (_ch != ch) return;
    connected.value = false;
    _ping?.cancel();
    if (_closed) return;
    final delay = Duration(seconds: min(30, 1 << min(_retry, 5)));
    _retry++;
    _reconnect?.cancel();
    _reconnect = Timer(delay, _open);
  }

  bool send(Map<String, dynamic> m) {
    if (!connected.value || _ch == null) return false;
    _ch!.sink.add(jsonEncode(m));
    return true;
  }

  void disconnect() {
    _closed = true;
    _ping?.cancel();
    _reconnect?.cancel();
    _ch?.sink.close();
    _ch = null;
    connected.value = false;
  }
}
