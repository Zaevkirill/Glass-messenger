import 'package:flutter/material.dart';
import '../../core/glass.dart';
import '../../core/theme.dart';
import '../settings/settings_screen.dart';
import 'chats_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _i = 0;

  @override
  Widget build(BuildContext context) => GlassScaffold(
        body: IndexedStack(index: _i, children: const [ChatsScreen(), SettingsScreen()]),
        bottom: SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(48, 0, 48, 14),
            child: GlassCard(
              radius: 30,
              padding: const EdgeInsets.all(6),
              strong: true,
              child: Row(children: [
                _NavItem(icon: Icons.chat_bubble_rounded, label: 'Чаты', selected: _i == 0, onTap: () => setState(() => _i = 0)),
                _NavItem(icon: Icons.settings_rounded, label: 'Настройки', selected: _i == 1, onTap: () => setState(() => _i = 1)),
              ]),
            ),
          ),
        ),
      );
}

class _NavItem extends StatelessWidget {
  const _NavItem({required this.icon, required this.label, required this.selected, required this.onTap});
  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) {
    final g = context.g;
    return Expanded(
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 280),
          curve: Curves.easeOutCubic,
          padding: const EdgeInsets.symmetric(vertical: 11),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            gradient: selected ? LinearGradient(colors: [g.neon.withAlpha(200), g.neon2.withAlpha(200)]) : null,
          ),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, size: 20, color: selected ? Colors.white : g.textDim),
            if (selected) ...[
              const SizedBox(width: 8),
              Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
            ],
          ]),
        ),
      ),
    );
  }
}
