import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/api.dart';
import '../../core/glass.dart';
import '../../core/models.dart';
import '../../core/session.dart';
import '../../core/theme.dart';
import '../chat/chat_screen.dart';

/// Поиск пользователей: по @username (префикс) или по номеру телефона (точное совпадение)
class NewChatScreen extends StatefulWidget {
  const NewChatScreen({super.key});
  @override
  State<NewChatScreen> createState() => _NewChatScreenState();
}

class _NewChatScreenState extends State<NewChatScreen> {
  final _c = TextEditingController();
  Timer? _deb;
  List<AppUser> _res = [];
  bool _loading = false, _searched = false;
  String? _err;

  void _onChanged(String v) {
    _deb?.cancel();
    final q = v.trim();
    if (q.length < 2) {
      setState(() {
        _res = [];
        _searched = false;
        _err = null;
      });
      return;
    }
    setState(() => _loading = true);
    _deb = Timer(const Duration(milliseconds: 350), () async {
      try {
        final r = await context.read<AppState>().api.search(q);
        if (mounted && _c.text.trim() == q) {
          setState(() {
            _res = r;
            _searched = true;
            _err = null;
            _loading = false;
          });
        }
      } on ApiError catch (e) {
        if (mounted) {
          setState(() {
            _err = e.message;
            _loading = false;
          });
        }
      }
    });
  }

  @override
  void dispose() {
    _deb?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final g = context.g;
    return GlassScaffold(
      appBar: glassAppBar(context, title: const Text('Новый чат', style: TextStyle(fontWeight: FontWeight.w700))),
      body: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 8),
            child: GlassTextField(
              controller: _c,
              hint: '@username или +7 999 123-45-67',
              icon: Icons.search_rounded,
              autofocus: true,
              onChanged: _onChanged,
            ),
          ),
          if (_loading) const Padding(padding: EdgeInsets.all(8), child: LinearProgressIndicator(minHeight: 2)),
          if (_err != null) Padding(padding: const EdgeInsets.all(12), child: Text(_err!, style: const TextStyle(color: Color(0xFFFF5470)))),
          Expanded(
            child: _res.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 32),
                      child: Text(
                        _searched ? 'Никого не найдено' : 'Введите @username или полный номер телефона в международном формате',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: g.textDim),
                      ),
                    ),
                  )
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                    itemCount: _res.length,
                    itemBuilder: (_, i) {
                      final u = _res[i];
                      return FadeSlideIn(
                        index: i,
                        child: Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: GlassCard(
                            radius: 22,
                            blur: 14,
                            padding: const EdgeInsets.all(12),
                            onTap: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => ChatScreen(peer: u))),
                            child: Row(children: [
                              GlassAvatar(initials: u.initials, size: 48),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Text(u.fullName, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                                  Text('@${u.username}', style: TextStyle(color: g.neon2)),
                                ]),
                              ),
                              Icon(Icons.chevron_right_rounded, color: g.textDim),
                            ]),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ]),
      ),
    );
  }
}
