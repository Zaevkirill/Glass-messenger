import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/glass.dart';
import '../../core/models.dart';
import '../../core/session.dart';
import '../../core/theme.dart';
import '../chat/chat_screen.dart';
import 'new_chat_screen.dart';

class ChatsScreen extends StatefulWidget {
  const ChatsScreen({super.key});
  @override
  State<ChatsScreen> createState() => _ChatsScreenState();
}

class _ChatsScreenState extends State<ChatsScreen> {
  final _q = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final g = context.g;
    final chats = context.watch<ChatsState>();
    final me = context.read<AppState>().user;
    final q = _q.text.trim().toLowerCase().replaceFirst('@', '');
    final list = q.isEmpty
        ? chats.chats
        : chats.chats.where((c) => c.peer.fullName.toLowerCase().contains(q) || c.peer.username.toLowerCase().contains(q)).toList();

    return SafeArea(
      bottom: false,
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
          child: Row(children: [
            Expanded(child: Text('Чаты', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800))),
            ValueListenableBuilder<bool>(
              valueListenable: context.read<AppState>().socket.connected,
              builder: (_, on, __) => Container(
                width: 9,
                height: 9,
                margin: const EdgeInsets.only(right: 14),
                decoration: BoxDecoration(shape: BoxShape.circle, color: on ? const Color(0xFF22C55E) : const Color(0xFFFFB020)),
              ),
            ),
            GlassIconButton(
              icon: Icons.edit_rounded,
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NewChatScreen())),
            ),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: GlassTextField(controller: _q, hint: 'Поиск по чатам', icon: Icons.search_rounded, onChanged: (_) => setState(() {})),
        ),
        const SizedBox(height: 8),
        Expanded(
          child: RefreshIndicator(
            onRefresh: chats.refresh,
            child: list.isEmpty
                ? ListView(children: [
                    SizedBox(height: MediaQuery.of(context).size.height * 0.18),
                    Icon(Icons.forum_outlined, size: 56, color: g.textDim),
                    const SizedBox(height: 14),
                    Center(
                      child: Text(
                        chats.loading ? 'Загрузка…' : (q.isEmpty ? 'Пока нет диалогов' : 'Ничего не найдено'),
                        style: TextStyle(color: g.textDim, fontSize: 16),
                      ),
                    ),
                    if (q.isEmpty && !chats.loading)
                      Padding(
                        padding: const EdgeInsets.only(top: 6),
                        child: Center(child: Text('Нажмите ✎ и найдите человека по @username', style: TextStyle(color: g.textDim))),
                      ),
                  ])
                : ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 110),
                    itemCount: list.length,
                    itemBuilder: (_, i) => FadeSlideIn(index: i, child: _ChatTile(preview: list[i], myId: me?.id ?? 0)),
                  ),
          ),
        ),
      ]),
    );
  }
}

class _ChatTile extends StatelessWidget {
  const _ChatTile({required this.preview, required this.myId});
  final ChatPreview preview;
  final int myId;

  @override
  Widget build(BuildContext context) {
    final g = context.g;
    final last = preview.last;
    final mine = last.from == myId;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GlassCard(
        radius: 22,
        blur: 14,
        padding: const EdgeInsets.all(12),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(peer: preview.peer))),
        child: Row(children: [
          GlassAvatar(initials: preview.peer.initials, size: 52),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(preview.peer.fullName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              const SizedBox(height: 3),
              Text('${mine ? 'Вы: ' : ''}${last.text}', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: g.textDim)),
            ]),
          ),
          const SizedBox(width: 8),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text(fmtChatTime(last.createdAt), style: TextStyle(color: g.textDim, fontSize: 12)),
            const SizedBox(height: 6),
            if (preview.unread > 0)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), gradient: LinearGradient(colors: [g.neon, g.neon2])),
                child: Text('${preview.unread}', style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
              )
            else if (mine)
              StatusTicks(last.status)
            else
              const SizedBox(height: 16),
          ]),
        ]),
      ),
    );
  }
}
