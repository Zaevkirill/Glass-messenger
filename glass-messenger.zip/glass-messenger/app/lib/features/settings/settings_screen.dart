import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/glass.dart';
import '../../core/session.dart';
import '../../core/theme.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final g = context.g;
    final app = context.watch<AppState>();
    final theme = context.watch<ThemeController>();
    final u = app.user;
    if (u == null) return const SizedBox();

    return SafeArea(
      bottom: false,
      child: ListView(padding: const EdgeInsets.fromLTRB(20, 12, 20, 110), children: [
        Text('Профиль', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
        const SizedBox(height: 18),
        FadeSlideIn(
          child: GlassCard(
            glow: true,
            padding: const EdgeInsets.symmetric(vertical: 26, horizontal: 20),
            child: Center(
              child: Column(children: [
                GlassAvatar(initials: u.initials, size: 96),
                const SizedBox(height: 14),
                Text(u.fullName, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                const SizedBox(height: 2),
                Text('@${u.username}', style: TextStyle(color: g.neon2, fontSize: 16)),
              ]),
            ),
          ),
        ),
        const SizedBox(height: 14),
        FadeSlideIn(
          index: 1,
          child: GlassCard(
            padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 16),
            child: Column(children: [
              _Row(Icons.alternate_email_rounded, 'Юзернейм', '@${u.username}'),
              _Row(Icons.phone_outlined, 'Телефон', u.phone ?? 'Не указан'),
              _Row(Icons.mail_outline_rounded, 'Почта', u.email ?? '—'),
            ]),
          ),
        ),
        const SizedBox(height: 14),
        FadeSlideIn(
          index: 2,
          child: GlassCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Тема оформления', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
              const SizedBox(height: 12),
              Row(children: [
                Expanded(child: _ThemeOption(label: 'Dark Glass', icon: Icons.dark_mode_rounded, selected: theme.mode == ThemeMode.dark, onTap: () => theme.set(ThemeMode.dark))),
                const SizedBox(width: 10),
                Expanded(child: _ThemeOption(label: 'Light Glass', icon: Icons.light_mode_rounded, selected: theme.mode == ThemeMode.light, onTap: () => theme.set(ThemeMode.light))),
              ]),
            ]),
          ),
        ),
        const SizedBox(height: 22),
        FadeSlideIn(
          index: 3,
          child: GlassButton(
            label: 'Выйти из аккаунта',
            icon: Icons.logout_rounded,
            danger: true,
            onPressed: () async {
              final ok = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: const Text('Выйти?'),
                  content: const Text('Вы сможете войти снова по почте и коду.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Отмена')),
                    TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Выйти')),
                  ],
                ),
              );
              if (ok == true) await app.logout();
            },
          ),
        ),
      ]),
    );
  }
}

class _Row extends StatelessWidget {
  const _Row(this.icon, this.label, this.value);
  final IconData icon;
  final String label, value;
  @override
  Widget build(BuildContext context) {
    final g = context.g;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Row(children: [
        Icon(icon, color: g.textDim, size: 22),
        const SizedBox(width: 12),
        Text(label, style: TextStyle(color: g.textDim)),
        const Spacer(),
        Flexible(child: Text(value, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600))),
      ]),
    );
  }
}

class _ThemeOption extends StatelessWidget {
  const _ThemeOption({required this.label, required this.icon, required this.selected, required this.onTap});
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) {
    final g = context.g;
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          gradient: selected ? LinearGradient(colors: [g.neon.withAlpha(210), g.neon2.withAlpha(210)]) : null,
          border: Border.all(color: selected ? Colors.transparent : g.border),
        ),
        child: Column(children: [
          Icon(icon, color: selected ? Colors.white : null),
          const SizedBox(height: 6),
          Text(label, style: TextStyle(fontWeight: FontWeight.w600, color: selected ? Colors.white : null)),
        ]),
      ),
    );
  }
}
