import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/glass.dart';
import '../../core/models.dart';
import '../../core/session.dart';
import '../../core/theme.dart';

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, required this.peer});
  final AppUser peer;
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  late final AppState _app;
  final _msgs = <Msg>[];
  final _input = TextEditingController();
  final _scroll = ScrollController();
  StreamSubscription? _sub;
  bool _loading = true;
  String? _err;

  @override
  void initState() {
    super.initState();
    _app = context.read<AppState>();
    _sub = _app.socket.events.listen(_onEvent);
    _load();
  }

  @override
  void dispose() {
    _sub?.cancel();
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final list = await _app.api.messages(widget.peer.id);
      if (!mounted) return;
      final pending = _msgs.where((m) => m.id == null).toList(); // ещё не подтверждённые сервером
      setState(() {
        _msgs
          ..clear()
          ..addAll(list)
          ..addAll(pending);
        _loading = false;
        _err = null;
      });
      _markRead();
      _toBottom(jump: true);
    } catch (e) {
      if (mounted) {
        setState(() {
          _loading = false;
          _err = e.toString();
        });
      }
    }
  }

  void _markRead() => _app.socket.send({'type': 'message:read', 'peerId': widget.peer.id});

  void _onEvent(Map<String, dynamic> m) {
    switch (m['type']) {
      case 'socket:open':
        _load(); // догружаем то, что пришло, пока были оффлайн
        break;
      case 'message:new':
        final msg = Msg.fromJson(Map<String, dynamic>.from(m['message'] as Map));
        if (msg.from == widget.peer.id && !_msgs.any((x) => x.id == msg.id)) {
          setState(() => _msgs.add(msg));
          _markRead();
          _toBottom();
        }
        break;
      case 'message:ack':
        final i = _msgs.indexWhere((x) => x.clientId == m['clientId']);
        if (i >= 0) {
          setState(() {
            _msgs[i]
              ..id = m['id'] as int
              ..createdAt = DateTime.fromMillisecondsSinceEpoch(m['createdAt'] as int)
              ..status = m['status'] as String;
          });
        }
        break;
      case 'message:status':
        final ids = (m['ids'] as List).cast<int>().toSet();
        setState(() {
          for (final x in _msgs) {
            if (x.id != null && ids.contains(x.id)) x.upgrade(m['status'] as String);
          }
        });
        break;
    }
  }

  void _send({Msg? retry}) {
    final text = _input.text.trim();
    if (retry == null && text.isEmpty) return;
    final m = retry ??
        Msg(
          clientId: 'c${DateTime.now().microsecondsSinceEpoch}',
          from: _app.user!.id,
          to: widget.peer.id,
          text: text,
          status: 'sending',
          createdAt: DateTime.now(),
        );
    if (retry == null) {
      _msgs.add(m);
      _input.clear();
    }
    m.status = 'sending';
    final ok = _app.socket.send({'type': 'message:send', 'to': widget.peer.id, 'text': m.text, 'clientId': m.clientId});
    if (!ok) m.status = 'failed';
    setState(() {});
    _toBottom();
  }

  void _toBottom({bool jump = false}) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_scroll.hasClients) return;
      final max = _scroll.position.maxScrollExtent;
      if (jump) {
        _scroll.jumpTo(max);
      } else {
        _scroll.animateTo(max, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      }
    });
  }

  Future<void> _call(bool video) async {
    final err = await _app.calls.start(widget.peer, withVideo: video);
    if (err != null && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(err)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final g = context.g;
    final p = widget.peer;
    return GlassScaffold(
      appBar: glassAppBar(
        context,
        title: Row(children: [
          GlassAvatar(initials: p.initials, size: 38),
          const SizedBox(width: 10),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(p.fullName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
              Text('@${p.username}', style: TextStyle(fontSize: 12, color: g.neon2)),
            ]),
          ),
        ]),
        actions: [
          IconButton(icon: const Icon(Icons.call_rounded), onPressed: () => _call(false)),
          IconButton(icon: const Icon(Icons.videocam_rounded), onPressed: () => _call(true)),
        ],
      ),
      body: Column(children: [
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator())
              : _msgs.isEmpty
                  ? Center(child: Text(_err ?? 'Напишите первое сообщение', style: TextStyle(color: g.textDim)))
                  : ListView.builder(
                      controller: _scroll,
                      padding: const EdgeInsets.fromLTRB(14, 8, 14, 8),
                      itemCount: _msgs.length,
                      itemBuilder: (_, i) => _Bubble(msg: _msgs[i], mine: _msgs[i].from == _app.user!.id, onRetry: () => _send(retry: _msgs[i])),
                    ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 4, 12, 10),
            child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Expanded(
                child: GlassTextField(controller: _input, hint: 'Сообщение', maxLines: 5, textInputAction: TextInputAction.newline),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: () => _send(),
                child: Container(
                  width: 52,
                  height: 52,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(colors: [g.neon, g.neon2]),
                    boxShadow: [BoxShadow(color: g.neon.withAlpha(90), blurRadius: 16)],
                  ),
                  child: const Icon(Icons.arrow_upward_rounded, color: Colors.white),
                ),
              ),
            ]),
          ),
        ),
      ]),
    );
  }
}

class _Bubble extends StatelessWidget {
  const _Bubble({required this.msg, required this.mine, required this.onRetry});
  final Msg msg;
  final bool mine;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    final g = context.g;
    final r = BorderRadius.only(
      topLeft: const Radius.circular(20),
      topRight: const Radius.circular(20),
      bottomLeft: Radius.circular(mine ? 20 : 5),
      bottomRight: Radius.circular(mine ? 5 : 20),
    );
    final timeColor = mine ? Colors.white.withAlpha(190) : g.textDim;
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: const Duration(milliseconds: 260),
      curve: Curves.easeOutCubic,
      builder: (_, v, c) => Opacity(opacity: v, child: Transform.translate(offset: Offset(0, (1 - v) * 10), child: c)),
      child: Align(
        alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
        child: GestureDetector(
          onTap: msg.status == 'failed' ? onRetry : null,
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 3),
            padding: const EdgeInsets.fromLTRB(14, 9, 12, 7),
            constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
            decoration: BoxDecoration(
              borderRadius: r,
              gradient: mine ? LinearGradient(colors: [g.neon.withAlpha(235), g.neon2.withAlpha(215)]) : null,
              color: mine ? null : g.fillStrong,
              border: Border.all(color: mine ? Colors.white.withAlpha(50) : g.border),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.end, mainAxisSize: MainAxisSize.min, children: [
              Align(
                alignment: Alignment.centerLeft,
                child: Text(msg.text, style: TextStyle(fontSize: 16, color: mine ? Colors.white : null)),
              ),
              const SizedBox(height: 3),
              Row(mainAxisSize: MainAxisSize.min, children: [
                if (msg.status == 'failed') const Text('Не отправлено · нажмите, чтобы повторить  ', style: TextStyle(fontSize: 11, color: Color(0xFFFF5470))),
                Text(fmtTime(msg.createdAt), style: TextStyle(fontSize: 11, color: timeColor)),
                if (mine) ...[const SizedBox(width: 4), StatusTicks(msg.status, color: timeColor)],
              ]),
            ]),
          ),
        ),
      ),
    );
  }
}
