import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../core/api.dart';
import '../../core/glass.dart';
import '../../core/models.dart';
import '../../core/session.dart';
import '../../core/theme.dart';

/// Данные регистрации, накапливаются по шагам 3–5
class RegData {
  String email = '';
  String registrationToken = '';
  String username = '';
  String firstName = '';
  String lastName = '';
  String? phone;
}

class AuthShell extends StatelessWidget {
  const AuthShell({super.key, required this.step, required this.title, required this.subtitle, required this.children});
  final int step;
  final String title, subtitle;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    final g = context.g;
    return GlassScaffold(
      appBar: glassAppBar(context),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
          child: FadeSlideIn(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                for (var i = 1; i <= 5; i++)
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    margin: const EdgeInsets.only(right: 6),
                    height: 5,
                    width: i == step ? 28 : 10,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(3),
                      color: i <= step ? g.neon2 : g.border,
                    ),
                  ),
              ]),
              const SizedBox(height: 28),
              Text(title, style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              Text(subtitle, style: TextStyle(color: g.textDim, fontSize: 15)),
              const SizedBox(height: 28),
              ...children,
            ]),
          ),
        ),
      ),
    );
  }
}

Widget _error(BuildContext context, String? e) => e == null
    ? const SizedBox(height: 8)
    : Padding(
        padding: const EdgeInsets.only(top: 10, bottom: 4),
        child: Text(e, style: const TextStyle(color: Color(0xFFFF5470))),
      );

void _finishAuth(BuildContext context) => Navigator.of(context).popUntil((r) => r.isFirst);

// ───────────── Шаг 1: Email ─────────────
class EmailScreen extends StatefulWidget {
  const EmailScreen({super.key});
  @override
  State<EmailScreen> createState() => _EmailScreenState();
}

class _EmailScreenState extends State<EmailScreen> {
  final _c = TextEditingController();
  bool _loading = false;
  String? _err;

  bool get _valid => RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(_c.text.trim());

  Future<void> _submit() async {
    if (!_valid || _loading) return;
    setState(() {
      _loading = true;
      _err = null;
    });
    try {
      final email = _c.text.trim().toLowerCase();
      final r = await context.read<AppState>().api.requestCode(email);
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(builder: (_) => CodeScreen(email: email, devCode: r['devCode'] as String?)));
    } on ApiError catch (e) {
      setState(() => _err = e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => AuthShell(
        step: 1,
        title: 'Добро пожаловать',
        subtitle: 'Введите почту — мы отправим 6-значный код подтверждения.',
        children: [
          GlassTextField(
            controller: _c,
            hint: 'name@example.com',
            icon: Icons.mail_outline_rounded,
            keyboardType: TextInputType.emailAddress,
            autofocus: true,
            textInputAction: TextInputAction.done,
            onChanged: (_) => setState(() {}),
            onSubmitted: (_) => _submit(),
          ),
          _error(context, _err),
          const SizedBox(height: 12),
          GlassButton(label: 'Получить код', onPressed: _valid ? _submit : null, loading: _loading),
        ],
      );
}

// ───────────── Шаг 2: Код ─────────────
class CodeScreen extends StatefulWidget {
  const CodeScreen({super.key, required this.email, this.devCode});
  final String email;
  final String? devCode;
  @override
  State<CodeScreen> createState() => _CodeScreenState();
}

class _CodeScreenState extends State<CodeScreen> {
  final _c = TextEditingController();
  bool _loading = false;
  String? _err, _devCode;
  int _cooldown = 30;
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _devCode = widget.devCode;
    _startTimer();
  }

  void _startTimer() {
    _cooldown = 30;
    _t?.cancel();
    _t = Timer.periodic(const Duration(seconds: 1), (t) {
      if (_cooldown <= 1) t.cancel();
      if (mounted) setState(() => _cooldown--);
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    super.dispose();
  }

  Future<void> _verify() async {
    if (_c.text.length != 6 || _loading) return;
    setState(() {
      _loading = true;
      _err = null;
    });
    final app = context.read<AppState>();
    try {
      final r = await app.api.verifyCode(widget.email, _c.text);
      if (!mounted) return;
      if (r['isNew'] == true) {
        final reg = RegData()
          ..email = widget.email
          ..registrationToken = r['registrationToken'] as String;
        Navigator.push(context, MaterialPageRoute(builder: (_) => UsernameScreen(reg: reg)));
      } else {
        await app.setSession(r['token'] as String, AppUser.fromJson(Map<String, dynamic>.from(r['user'] as Map)));
        if (mounted) _finishAuth(context);
      }
    } on ApiError catch (e) {
      setState(() {
        _err = e.message;
        _c.clear();
      });
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _resend() async {
    try {
      final r = await context.read<AppState>().api.requestCode(widget.email);
      setState(() {
        _devCode = r['devCode'] as String?;
        _err = null;
      });
      _startTimer();
    } on ApiError catch (e) {
      setState(() => _err = e.message);
    }
  }

  @override
  Widget build(BuildContext context) {
    final g = context.g;
    return AuthShell(
      step: 2,
      title: 'Код из письма',
      subtitle: 'Мы отправили код на ${widget.email}',
      children: [
        GlassTextField(
          controller: _c,
          hint: '••••••',
          keyboardType: TextInputType.number,
          autofocus: true,
          maxLength: 6,
          textAlign: TextAlign.center,
          textStyle: const TextStyle(fontSize: 32, letterSpacing: 12, fontWeight: FontWeight.w700),
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          onChanged: (v) {
            setState(() {});
            if (v.length == 6) _verify();
          },
        ),
        _error(context, _err),
        if (_devCode != null) ...[
          const SizedBox(height: 8),
          GlassCard(
            radius: 16,
            padding: const EdgeInsets.all(12),
            child: Text('DEV-режим: код $_devCode (в production не показывается; сейчас он также в консоли сервера)',
                style: TextStyle(color: g.textDim, fontSize: 13)),
          ),
        ],
        const SizedBox(height: 16),
        GlassButton(label: 'Подтвердить', onPressed: _c.text.length == 6 ? _verify : null, loading: _loading),
        const SizedBox(height: 8),
        Center(
          child: TextButton(
            onPressed: _cooldown > 0 ? null : _resend,
            child: Text(_cooldown > 0 ? 'Отправить снова через $_cooldown c' : 'Отправить код снова'),
          ),
        ),
      ],
    );
  }
}

// ───────────── Шаг 3: @username ─────────────
class UsernameScreen extends StatefulWidget {
  const UsernameScreen({super.key, required this.reg});
  final RegData reg;
  @override
  State<UsernameScreen> createState() => _UsernameScreenState();
}

enum _UState { idle, checking, ok, taken, invalid }

class _UsernameScreenState extends State<UsernameScreen> {
  final _c = TextEditingController();
  _UState _s = _UState.idle;
  Timer? _deb;
  static final _re = RegExp(r'^[A-Za-z][A-Za-z0-9_]{4,31}$');

  void _onChanged(String v) {
    _deb?.cancel();
    if (v.isEmpty) return setState(() => _s = _UState.idle);
    if (!_re.hasMatch(v)) return setState(() => _s = _UState.invalid);
    setState(() => _s = _UState.checking);
    _deb = Timer(const Duration(milliseconds: 400), () async {
      try {
        final ok = await context.read<AppState>().api.usernameAvailable(v);
        if (mounted && _c.text == v) setState(() => _s = ok ? _UState.ok : _UState.taken);
      } on ApiError {
        if (mounted) setState(() => _s = _UState.idle);
      }
    });
  }

  @override
  void dispose() {
    _deb?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final g = context.g;
    final (text, color) = switch (_s) {
      _UState.idle => ('От 5 до 32 символов: латиница, цифры и _', g.textDim),
      _UState.checking => ('Проверяем…', g.textDim),
      _UState.ok => ('@${_c.text} свободен', const Color(0xFF22C55E)),
      _UState.taken => ('Этот @username уже занят', const Color(0xFFFF5470)),
      _UState.invalid => ('Начинается с буквы, 5–32 символа: a–z, 0–9, _', const Color(0xFFFF5470)),
    };
    return AuthShell(
      step: 3,
      title: 'Ваш @username',
      subtitle: 'По нему вас смогут найти другие пользователи.',
      children: [
        GlassTextField(
          controller: _c,
          hint: 'username',
          prefixText: '@',
          autofocus: true,
          maxLength: 32,
          inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[A-Za-z0-9_]'))],
          onChanged: _onChanged,
        ),
        Padding(padding: const EdgeInsets.only(top: 10, bottom: 18), child: Text(text, style: TextStyle(color: color))),
        GlassButton(
          label: 'Продолжить',
          onPressed: _s == _UState.ok
              ? () {
                  widget.reg.username = _c.text;
                  Navigator.push(context, MaterialPageRoute(builder: (_) => NameScreen(reg: widget.reg)));
                }
              : null,
        ),
      ],
    );
  }
}

// ───────────── Шаг 4: Имя и фамилия ─────────────
class NameScreen extends StatefulWidget {
  const NameScreen({super.key, required this.reg});
  final RegData reg;
  @override
  State<NameScreen> createState() => _NameScreenState();
}

class _NameScreenState extends State<NameScreen> {
  final _f = TextEditingController(), _l = TextEditingController();
  bool get _ok => _f.text.trim().isNotEmpty && _l.text.trim().isNotEmpty;

  @override
  Widget build(BuildContext context) => AuthShell(
        step: 4,
        title: 'Как вас зовут?',
        subtitle: 'Имя и фамилия будут видны вашим контактам.',
        children: [
          GlassTextField(
            controller: _f,
            hint: 'Имя',
            icon: Icons.person_outline_rounded,
            autofocus: true,
            maxLength: 40,
            textInputAction: TextInputAction.next,
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 12),
          GlassTextField(
            controller: _l,
            hint: 'Фамилия',
            icon: Icons.badge_outlined,
            maxLength: 40,
            textInputAction: TextInputAction.done,
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 24),
          GlassButton(
            label: 'Продолжить',
            onPressed: _ok
                ? () {
                    widget.reg
                      ..firstName = _f.text.trim()
                      ..lastName = _l.text.trim();
                    Navigator.push(context, MaterialPageRoute(builder: (_) => PhoneScreen(reg: widget.reg)));
                  }
                : null,
          ),
        ],
      );
}

// ───────────── Шаг 5: Телефон (опционально) ─────────────
class PhoneScreen extends StatefulWidget {
  const PhoneScreen({super.key, required this.reg});
  final RegData reg;
  @override
  State<PhoneScreen> createState() => _PhoneScreenState();
}

class _PhoneScreenState extends State<PhoneScreen> {
  final _c = TextEditingController();
  bool _loading = false;
  String? _err;

  Future<void> _finish({required bool withPhone}) async {
    setState(() {
      _loading = true;
      _err = null;
    });
    final app = context.read<AppState>();
    final r = widget.reg;
    try {
      final res = await app.api.register(
        registrationToken: r.registrationToken,
        username: r.username,
        firstName: r.firstName,
        lastName: r.lastName,
        phone: withPhone && _c.text.trim().isNotEmpty ? _c.text.trim() : null,
      );
      await app.setSession(res['token'] as String, AppUser.fromJson(Map<String, dynamic>.from(res['user'] as Map)));
      if (mounted) _finishAuth(context);
    } on ApiError catch (e) {
      setState(() => _err = e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) => AuthShell(
        step: 5,
        title: 'Номер телефона',
        subtitle: 'Необязательно. Друзья смогут найти вас по номеру. Формат: +7 999 123-45-67',
        children: [
          GlassTextField(
            controller: _c,
            hint: '+7 999 123-45-67',
            icon: Icons.phone_outlined,
            keyboardType: TextInputType.phone,
            autofocus: true,
            maxLength: 20,
            inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9+\-\s()]'))],
            onChanged: (_) => setState(() {}),
          ),
          _error(context, _err),
          const SizedBox(height: 12),
          GlassButton(
            label: 'Готово',
            loading: _loading,
            onPressed: _c.text.trim().length >= 7 ? () => _finish(withPhone: true) : null,
          ),
          const SizedBox(height: 8),
          Center(child: TextButton(onPressed: _loading ? null : () => _finish(withPhone: false), child: const Text('Пропустить'))),
        ],
      );
}
