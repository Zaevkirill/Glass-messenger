import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../core/api.dart';
import '../../core/models.dart';
import '../../core/socket.dart';
import 'call_screen.dart';

final rootNavKey = GlobalKey<NavigatorState>();
final rootMessengerKey = GlobalKey<ScaffoldMessengerState>();

enum CallPhase { idle, calling, ringing, connecting, connected }

/// Аудио/видеозвонки 1-на-1 поверх WebRTC.
/// Сигналинг (offer/answer/ICE) идёт через тот же WebSocket, медиа — напрямую P2P
/// (или через TURN, если прямой путь невозможен — это даёт работу во всех странах/сетях).
class CallService extends ChangeNotifier {
  CallService(this._api, this._socket) {
    _socket.events.listen(_onEvent);
  }
  final Api _api;
  final ChatSocket _socket;

  final localRenderer = RTCVideoRenderer();
  final remoteRenderer = RTCVideoRenderer();
  bool _renderersReady = false;

  CallPhase phase = CallPhase.idle;
  AppUser? peer;
  String? callId;
  bool video = false, muted = false, camOff = false, speaker = true;

  RTCPeerConnection? _pc;
  MediaStream? _local;
  Map<String, dynamic>? _offer;
  final List<RTCIceCandidate> _iceQueue = [];
  bool _remoteSet = false;
  bool _screenOpen = false;

  Future<void> _ensureRenderers() async {
    if (_renderersReady) return;
    await localRenderer.initialize();
    await remoteRenderer.initialize();
    _renderersReady = true;
  }

  String _newId() => '${DateTime.now().microsecondsSinceEpoch}-${Random().nextInt(1 << 20)}';

  void _toast(String s) => rootMessengerKey.currentState?.showSnackBar(SnackBar(content: Text(s)));

  Future<bool> _perms(bool withVideo) async {
    final st = await [Permission.microphone, if (withVideo) Permission.camera].request();
    return st.values.every((s) => s.isGranted);
  }

  // ---------- Исходящий звонок ----------
  /// Возвращает текст ошибки или null, если звонок начался.
  Future<String?> start(AppUser to, {required bool withVideo}) async {
    if (phase != CallPhase.idle) return 'Вы уже в звонке';
    if (!_socket.connected.value) return 'Нет соединения с сервером';
    if (!await _perms(withVideo)) return 'Нет доступа к микрофону/камере';
    await _ensureRenderers();
    peer = to;
    video = withVideo;
    callId = _newId();
    phase = CallPhase.calling;
    muted = false;
    camOff = false;
    notifyListeners();
    _openScreen();
    try {
      await _setupPc();
      final offer = await _pc!.createOffer();
      await _pc!.setLocalDescription(offer);
      _socket.send({'type': 'call:offer', 'to': to.id, 'callId': callId, 'video': withVideo, 'sdp': offer.sdp});
    } catch (_) {
      _cleanup();
      return 'Не удалось начать звонок';
    }
    return null;
  }

  // ---------- Входящий звонок ----------
  Future<void> accept() async {
    if (phase != CallPhase.ringing || _offer == null) return;
    if (!await _perms(video)) {
      _toast('Нет доступа к микрофону/камере');
      decline();
      return;
    }
    phase = CallPhase.connecting;
    notifyListeners();
    try {
      await _setupPc();
      await _pc!.setRemoteDescription(RTCSessionDescription(_offer!['sdp'] as String?, 'offer'));
      _remoteSet = true;
      await _flushIce();
      final answer = await _pc!.createAnswer();
      await _pc!.setLocalDescription(answer);
      _socket.send({'type': 'call:answer', 'to': peer!.id, 'callId': callId, 'sdp': answer.sdp});
    } catch (_) {
      _toast('Не удалось принять звонок');
      end();
    }
  }

  void decline() {
    if (peer != null) _socket.send({'type': 'call:reject', 'to': peer!.id, 'callId': callId});
    _cleanup();
  }

  void end() {
    if (peer != null && callId != null) _socket.send({'type': 'call:end', 'to': peer!.id, 'callId': callId});
    _cleanup();
  }

  // ---------- Управление ----------
  void toggleMute() {
    muted = !muted;
    _local?.getAudioTracks().forEach((t) => t.enabled = !muted);
    notifyListeners();
  }

  void toggleCamera() {
    camOff = !camOff;
    _local?.getVideoTracks().forEach((t) => t.enabled = !camOff);
    notifyListeners();
  }

  void toggleSpeaker() {
    speaker = !speaker;
    Helper.setSpeakerphoneOn(speaker);
    notifyListeners();
  }

  void switchCamera() {
    final tracks = _local?.getVideoTracks() ?? [];
    if (tracks.isNotEmpty) Helper.switchCamera(tracks.first);
  }

  // ---------- Внутреннее ----------
  Future<List<Map<String, dynamic>>> _fetchIce() async {
    try {
      final d = await _api.get('/calls/ice-servers');
      return (d['iceServers'] as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
    } catch (_) {
      return [
        {'urls': ['stun:stun.l.google.com:19302']},
      ];
    }
  }

  Future<void> _setupPc() async {
    final ice = await _fetchIce();
    final pc = await createPeerConnection({'iceServers': ice, 'sdpSemantics': 'unified-plan', 'iceCandidatePoolSize': 2});
    _pc = pc;
    // Качество адаптируется автоматически (WebRTC congestion control); ограничиваем разрешение для слабых каналов
    _local = await navigator.mediaDevices.getUserMedia({
      'audio': {'echoCancellation': true, 'noiseSuppression': true, 'autoGainControl': true},
      'video': video
          ? {
              'facingMode': 'user',
              'width': {'ideal': 640},
              'height': {'ideal': 480},
              'frameRate': {'ideal': 24},
            }
          : false,
    });
    localRenderer.srcObject = _local;
    for (final t in _local!.getTracks()) {
      await pc.addTrack(t, _local!);
    }
    pc.onIceCandidate = (c) {
      if (c.candidate == null || peer == null) return;
      _socket.send({
        'type': 'call:ice',
        'to': peer!.id,
        'callId': callId,
        'candidate': {'candidate': c.candidate, 'sdpMid': c.sdpMid, 'sdpMLineIndex': c.sdpMLineIndex},
      });
    };
    pc.onTrack = (e) {
      if (e.streams.isNotEmpty) {
        remoteRenderer.srcObject = e.streams[0];
        notifyListeners();
      }
    };
    pc.onConnectionState = (s) {
      if (s == RTCPeerConnectionState.RTCPeerConnectionStateConnected) {
        phase = CallPhase.connected;
        Helper.setSpeakerphoneOn(video ? true : speaker);
        notifyListeners();
      } else if (s == RTCPeerConnectionState.RTCPeerConnectionStateFailed) {
        _toast('Соединение потеряно');
        end();
      }
    };
  }

  Future<void> _flushIce() async {
    for (final c in _iceQueue) {
      await _pc?.addCandidate(c);
    }
    _iceQueue.clear();
  }

  Future<void> _onEvent(Map<String, dynamic> m) async {
    switch (m['type']) {
      case 'call:offer':
        if (phase != CallPhase.idle) {
          _socket.send({'type': 'call:reject', 'to': m['from'], 'callId': m['callId'], 'reason': 'busy'});
          return;
        }
        peer = AppUser.fromJson(Map<String, dynamic>.from(m['caller'] as Map));
        callId = m['callId'] as String?;
        video = m['video'] == true;
        _offer = {'sdp': m['sdp'], 'type': 'offer'};
        phase = CallPhase.ringing;
        muted = false;
        camOff = false;
        notifyListeners();
        await _ensureRenderers();
        _openScreen();
        break;

      case 'call:answer':
        if (m['callId'] != callId || _pc == null) return;
        await _pc!.setRemoteDescription(RTCSessionDescription(m['sdp'] as String?, 'answer'));
        _remoteSet = true;
        await _flushIce();
        phase = CallPhase.connecting;
        notifyListeners();
        break;

      case 'call:ice':
        if (m['callId'] != callId) return;
        final c = Map<String, dynamic>.from(m['candidate'] as Map);
        final cand = RTCIceCandidate(c['candidate'] as String?, c['sdpMid'] as String?, c['sdpMLineIndex'] as int?);
        if (_remoteSet && _pc != null) {
          await _pc!.addCandidate(cand);
        } else {
          _iceQueue.add(cand);
        }
        break;

      case 'call:end':
        if (m['callId'] != callId) return;
        _cleanup();
        break;

      case 'call:reject':
        if (m['callId'] != callId) return;
        _toast(m['reason'] == 'busy' ? 'Абонент занят' : 'Звонок отклонён');
        _cleanup();
        break;

      case 'call:unavailable':
        if (m['callId'] != callId) return;
        _toast('Абонент не в сети');
        _cleanup();
        break;
    }
  }

  void _openScreen() {
    if (_screenOpen) return;
    _screenOpen = true;
    rootNavKey.currentState?.push(MaterialPageRoute(fullscreenDialog: true, builder: (_) => const CallScreen()));
  }

  void _closeScreen() {
    if (!_screenOpen) return;
    _screenOpen = false;
    rootNavKey.currentState?.pop();
  }

  void _cleanup() {
    for (final t in _local?.getTracks() ?? <MediaStreamTrack>[]) {
      t.stop();
    }
    _local?.dispose();
    _pc?.close();
    _pc = null;
    _local = null;
    if (_renderersReady) {
      localRenderer.srcObject = null;
      remoteRenderer.srcObject = null;
    }
    _iceQueue.clear();
    _remoteSet = false;
    _offer = null;
    peer = null;
    callId = null;
    phase = CallPhase.idle;
    _closeScreen();
    notifyListeners();
  }
}
