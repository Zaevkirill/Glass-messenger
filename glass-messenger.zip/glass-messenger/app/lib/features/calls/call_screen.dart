import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:provider/provider.dart';
import '../../core/glass.dart';
import '../../core/theme.dart';
import 'call_service.dart';

class CallScreen extends StatelessWidget {
  const CallScreen({super.key});

  String _status(CallService c) {
    switch (c.phase) {
      case CallPhase.calling:
        return 'Вызов…';
      case CallPhase.ringing:
        return c.video ? 'Входящий видеозвонок' : 'Входящий аудиозвонок';
      case CallPhase.connecting:
        return 'Соединение…';
      case CallPhase.connected:
        return c.video ? 'Видеозвонок' : 'Аудиозвонок';
      case CallPhase.idle:
        return '';
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = context.watch<CallService>();
    final g = context.g;
    final showVideo = c.video && c.phase == CallPhase.connected && c.remoteRenderer.srcObject != null;
    return PopScope(
      canPop: false, // выйти можно только завершив звонок
      child: GlassScaffold(
        body: Stack(children: [
          if (showVideo)
            Positioned.fill(child: RTCVideoView(c.remoteRenderer, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover)),
          SafeArea(
            child: Column(children: [
              const SizedBox(height: 40),
              if (!showVideo) ...[
                const Spacer(),
                GlassAvatar(initials: c.peer?.initials ?? '', size: 128),
                const SizedBox(height: 24),
              ],
              Text(c.peer?.fullName ?? '', style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w700)),
              const SizedBox(height: 6),
              Text(_status(c), style: TextStyle(color: g.textDim, fontSize: 15)),
              const Spacer(),
              if (c.video && c.localRenderer.srcObject != null && !c.camOff)
                Align(
                  alignment: Alignment.centerRight,
                  child: Padding(
                    padding: const EdgeInsets.only(right: 16, bottom: 16),
                    child: SizedBox(
                      width: 110,
                      height: 150,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(18),
                        child: RTCVideoView(c.localRenderer, mirror: true, objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover),
                      ),
                    ),
                  ),
                ),
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 28),
                child: GlassCard(
                  radius: 32,
                  padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 12),
                  child: c.phase == CallPhase.ringing
                      ? Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                          _RoundBtn(icon: Icons.call_end_rounded, color: const Color(0xFFFF4D6D), onTap: c.decline),
                          _RoundBtn(icon: c.video ? Icons.videocam_rounded : Icons.call_rounded, color: const Color(0xFF22C55E), onTap: c.accept),
                        ])
                      : Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                          _RoundBtn(icon: c.muted ? Icons.mic_off_rounded : Icons.mic_rounded, active: c.muted, onTap: c.toggleMute),
                          if (c.video) ...[
                            _RoundBtn(icon: c.camOff ? Icons.videocam_off_rounded : Icons.videocam_rounded, active: c.camOff, onTap: c.toggleCamera),
                            _RoundBtn(icon: Icons.cameraswitch_rounded, onTap: c.switchCamera),
                          ] else
                            _RoundBtn(icon: c.speaker ? Icons.volume_up_rounded : Icons.volume_down_rounded, active: !c.speaker, onTap: c.toggleSpeaker),
                          _RoundBtn(icon: Icons.call_end_rounded, color: const Color(0xFFFF4D6D), onTap: c.end),
                        ]),
                ),
              ),
            ]),
          ),
        ]),
      ),
    );
  }
}

class _RoundBtn extends StatelessWidget {
  const _RoundBtn({required this.icon, required this.onTap, this.color, this.active = false});
  final IconData icon;
  final VoidCallback onTap;
  final Color? color;
  final bool active;
  @override
  Widget build(BuildContext context) {
    final g = context.g;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 62,
        height: 62,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color ?? (active ? g.neon.withAlpha(200) : g.fillStrong),
          border: Border.all(color: g.border),
        ),
        child: Icon(icon, color: color != null || active ? Colors.white : null, size: 28),
      ),
    );
  }
}
