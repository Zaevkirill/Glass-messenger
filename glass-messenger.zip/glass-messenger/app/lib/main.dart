import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'core/glass.dart';
import 'core/session.dart';
import 'core/theme.dart';
import 'features/auth/auth_flow.dart';
import 'features/calls/call_service.dart';
import 'features/chats/home_shell.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final theme = ThemeController();
  final app = AppState();
  await theme.load();
  app.load(); // не блокируем запуск: пока идёт загрузка, Gate показывает индикатор
  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider.value(value: theme),
      ChangeNotifierProvider.value(value: app),
      ChangeNotifierProvider.value(value: app.chats),
      ChangeNotifierProvider.value(value: app.calls),
    ],
    child: const GlassApp(),
  ));
}

class GlassApp extends StatelessWidget {
  const GlassApp({super.key});

  @override
  Widget build(BuildContext context) {
    final t = context.watch<ThemeController>();
    return MaterialApp(
      title: 'Glass Messenger',
      debugShowCheckedModeBanner: false,
      navigatorKey: rootNavKey,
      scaffoldMessengerKey: rootMessengerKey,
      themeMode: t.mode,
      theme: buildTheme(Brightness.light),
      darkTheme: buildTheme(Brightness.dark),
      themeAnimationDuration: const Duration(milliseconds: 450),
      home: const Gate(),
    );
  }
}

/// Корневой экран: загрузка -> авторизация или главный экран
class Gate extends StatelessWidget {
  const Gate({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    if (!app.loaded) {
      return const GlassScaffold(body: Center(child: CircularProgressIndicator()));
    }
    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 350),
      child: app.user != null ? const HomeShell(key: ValueKey('home')) : const EmailScreen(key: ValueKey('auth')),
    );
  }
}
