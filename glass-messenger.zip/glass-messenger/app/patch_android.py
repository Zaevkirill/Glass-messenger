#!/usr/bin/env python3
"""Добавляет разрешения (интернет, камера, микрофон) и cleartext-HTTP (для локальной разработки)
в android/app/src/main/AndroidManifest.xml. Запускать из папки app/ после `flutter create .`"""
import re, sys, pathlib

p = pathlib.Path("android/app/src/main/AndroidManifest.xml")
if not p.exists():
    sys.exit("Не найден AndroidManifest.xml — сначала выполните: flutter create . --platforms=android")

s = p.read_text(encoding="utf-8")
perms = [
    "android.permission.INTERNET",
    "android.permission.ACCESS_NETWORK_STATE",
    "android.permission.CAMERA",
    "android.permission.RECORD_AUDIO",
    "android.permission.MODIFY_AUDIO_SETTINGS",
    "android.permission.BLUETOOTH",
    "android.permission.BLUETOOTH_CONNECT",
]
add = "".join(f'    <uses-permission android:name="{x}"/>\n' for x in perms if x not in s)
add += '    <uses-feature android:name="android.hardware.camera" android:required="false"/>\n' if 'hardware.camera"' not in s else ""
if add:
    s = s.replace("<application", add + "    <application", 1)
if "usesCleartextTraffic" not in s:
    s = s.replace("<application", '<application android:usesCleartextTraffic="true"', 1)
p.write_text(s, encoding="utf-8")
print("AndroidManifest.xml обновлён")
